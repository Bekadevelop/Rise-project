import React from 'react';

const Card = () => {
    return (
        <section className="card">
            <div className="container">

            </div>

        </section>
    );
};

export default Card;